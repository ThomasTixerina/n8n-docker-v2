<?php

namespace App\Core;

class Security {
    
    /**
     * Limpia recursivamente los datos de entrada para prevenir XSS y otras inyecciones básicas.
     * 
     * @param mixed $input
     * @return mixed
     */
    public static function clean($input) {
        if (is_array($input)) {
            foreach ($input as $key => $value) {
                // Limpiar también la clave
                $key = self::clean($key);
                $input[$key] = self::clean($value);
            }
            return $input;
        }

        // Si es string, aplicamos filtros
        if (is_string($input)) {
            // Trim de espacios
            $input = trim($input);
            // Convertir caracteres especiales a entidades HTML (evita XSS básico)
            // UTF-8 es el estándar, pero en legacy a veces es Latin1. Asumimos UTF-8 por modernización.
            $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
            return $input;
        }

        return $input;
    }

    /**
     * Ejecuta la limpieza en todas las superglobales de entrada.
     * Debería llamarse al inicio del script (ej. en index.php o db.php).
     */
    public static function cleanInputGlobals() {
        if (!empty($_GET)) {
            $_GET = self::clean($_GET);
        }
        if (!empty($_POST)) {
            $_POST = self::clean($_POST);
        }
        if (!empty($_REQUEST)) {
            $_REQUEST = self::clean($_REQUEST);
        }
        // $_COOKIE a veces se necesita sanitizar, pero con cuidado de no romper sesiones.
        if (!empty($_COOKIE)) {
            $_COOKIE = self::clean($_COOKIE);
        }
    }
}
