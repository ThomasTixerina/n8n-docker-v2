<?php

namespace App\Core;

class Webhook {
    
    /**
     * Envía un evento a n8n de forma asíncrona (fuego y olvido) o síncrona.
     * Para PHP legacy, usamos cURL con timeout bajo para no bloquear la UI.
     * 
     * @param string $endpoint  La URL del webhook de n8n (ej. /webhook/nuevo-paciente)
     * @param array $payload    Datos a enviar
     */
    public static function trigger($endpoint, $payload = []) {
        $baseUrl = getenv('N8N_WEBHOOK_URL'); // Ej: https://n8n.miconsul.com
        if (!$baseUrl) {
            // Si no está configurado, no hacemos nada (o logueamos error)
            error_log("N8N_WEBHOOK_URL no configurada.");
            return;
        }

        // Asegurar que el endpoint empiece con / si falta, o manejar URLs completas
        $url = rtrim($baseUrl, '/') . '/' . ltrim($endpoint, '/');

        $ch = curl_init($url);
        $jsonData = json_encode($payload);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'X-Source: MiConsul-PHP'
        ]);
        
        // Timeout muy corto para no ralentizar la experiencia del usuario (Fire & Forget simulado)
        curl_setopt($ch, CURLOPT_TIMEOUT_MS, 500); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        // En local a veces los certificados fallan
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        $result = curl_exec($ch);
        
        if (curl_errno($ch)) {
            // Loguear error silenciosamente
            error_log("Error enviando webhook a n8n: " . curl_error($ch));
        }

        curl_close($ch);
    }
}
