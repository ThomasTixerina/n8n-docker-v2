<?php
// app/db.php - Modernized Entry Point

// 1. Cargar el Autoloader o hacer requires manuales si no hay composer
require_once __DIR__ . '/Core/EnvLoader.php';
require_once __DIR__ . '/Core/Database.php';
require_once __DIR__ . '/Core/Security.php';
// require_once __DIR__ . '/Core/mysql_shim.php'; // Descomentar cuando el shim esté listo

use App\Core\EnvLoader;
use App\Core\Security;
use App\Core\Database;

// 2. Cargar Variables de Entorno (Fase 2)
// Buscamos el .env un nivel arriba de 'app' o en ROOT
$envPath = __DIR__ . '/../../.env'; 
if (file_exists($envPath)) {
    EnvLoader::load($envPath);
}

// 3. Sanitización Global (Fase 2)
Security::cleanInputGlobals();

// 4. Inicializar conexión "Legacy" (Shim) si es necesario
// El shim usará internamente Database::getInstance()
// init_mysql_shim(); 

// Prueba simple de conexión (para desarrollo/debug)
/*
try {
    $db = Database::getInstance();
    // echo "Conexión Exitosa (Modernizada)";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
*/
