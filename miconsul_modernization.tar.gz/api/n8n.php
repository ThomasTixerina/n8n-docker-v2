<?php
// api/n8n.php - Endpoint interno para n8n

// Bootstrap del sistema (carga DB y seguridad)
require_once __DIR__ . '/../app/db.php';

use App\Core\Database;

// Configuración
header('Content-Type: application/json');

// 1. Autenticación Simple (Fase 3)
$apiKey = getenv('N8N_API_KEY');
$requestKey = isset($_SERVER['HTTP_X_API_KEY']) ? $_SERVER['HTTP_X_API_KEY'] : (isset($_GET['key']) ? $_GET['key'] : '');

if (!$apiKey || $requestKey !== $apiKey) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// 2. Enrutamiento de Acciones
$action = isset($_GET['action']) ? $_GET['action'] : '';
$db = Database::getInstance();

try {
    switch ($action) {
        case 'get_daily_sales':
            // Ejemplo: obtener ventas del día para reporte
            $date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
            // Nota: Security::cleanInputGlobals ya sanitizó $_GET['date']
            
            $sql = "SELECT * FROM ospos_sales WHERE DATE(sale_time) = :date";
            $stmt = $db->query($sql, [':date' => $date]);
            $data = $stmt->fetchAll();
            echo json_encode(['status' => 'success', 'data' => $data]);
            break;

        case 'get_patient_details':
             $id = isset($_GET['id']) ? $_GET['id'] : 0;
             $sql = "SELECT p.*, pp.phone_number FROM ospos_people p 
                     JOIN ospos_customers c ON p.person_id = c.person_id
                     LEFT JOIN ospos_people_phones pp ON p.person_id = pp.person_id
                     WHERE p.person_id = :id";
             $stmt = $db->query($sql, [':id' => $id]);
             $data = $stmt->fetch();
             echo json_encode(['status' => 'success', 'data' => $data]);
             break;

        default:
            throw new Exception("Acción no válida: " . $action);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
